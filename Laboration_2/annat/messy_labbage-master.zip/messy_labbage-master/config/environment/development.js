'use strict';

// Development specific configuration
// ==================================
module.exports = {
  // noting yet
};
